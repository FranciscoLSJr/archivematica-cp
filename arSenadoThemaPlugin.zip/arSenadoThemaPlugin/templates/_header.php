<!-- componente navbar-senado -->
<script async src="https://www.google-analytics.com/analytics.js"></script>
<script>
    window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};

    ga.l=+new Date;
    ga('create', 'UA-101435193-1', 'auto', 'global', {'alwaysSendReferrer': true});
    var path = '/arquivo-digital' + location.pathname
    ga('global.send', 'pageview', path)
</script>
<div id="sf-partial-header">
  <?php include 'parts/navbar-senado.php'; ?>
</div>

<?php echo get_component('default', 'updateCheck') ?>

<?php echo get_component('default', 'privacyMessage') ?>

<?php if ($sf_user->isAdministrator() && (string)QubitSetting::getByName('siteBaseUrl') === ''): ?>
  <div class="site-warning">
    <?php echo link_to(__('Please configure your site base URL'), 'settings/siteInformation', array('rel' => 'home', 'title' => __('Home'))) ?>
  </div>
<?php endif; ?>

<header id="top-bar">
  <div class="sf-menu-left-navbar-flex">
    <div>
      <?php if (sfConfig::get('app_toggleLogo')): ?>
        <?php
          $path_logo_senado = 'plugins/arSenadoThemaPlugin/images/senado-federal-logo.png';
          $path_logo = file_exists($path_logo_senado) ? '../'.$path_logo_senado : 'logo' ;
          echo link_to(image_tag($path_logo, array('alt' => 'AtoM')), '@homepage', array('id' => 'logo', 'rel' => 'home'))
        ?>
      <?php endif; ?>
    </div>

    <div>
      <?php if (sfConfig::get('app_toggleTitle')): ?>
        <h1 id="site-name">
          <?php echo link_to('<span>'.esc_specialchars(sfConfig::get('app_siteTitle')).'</span>', '@homepage', array('rel' => 'home', 'title' => __('Home'))) ?>
        </h1>
      <?php endif; ?>
    </div>

    <div id="sf-button-navigation">
      <?php echo get_component('menu', 'browseMenu', array('sf_cache_key' => $sf_user->getCulture().$sf_user->getUserID())) ?>
    </div>
  </div>

  <div class="sf-menu-right-navbar-flex">

    <!-- <nav> -->
      <?php echo get_component('menu', 'mainMenu', array('sf_cache_key' => $sf_user->getCulture().$sf_user->getUserID())) ?>
      <?php echo get_component('menu', 'clipboardMenu') ?>
      <?php echo get_component('menu', 'quickLinksMenu') ?>

      <?php if (sfConfig::get('app_toggleLanguageMenu')): ?>
          <?php echo get_component('menu', 'changeLanguageMenu') ?>
      <?php endif; ?>

      <?php echo get_component('menu', 'userMenu') ?>
    <!-- </nav> -->
  </div>

</header>
  <div id="site-slogan" class="hero hero-img2 hero-lg hero-img-class" onclick="location.href='/index.php';" style="height:150px; cursor:pointer;">
    <div class="container">
      <div id="row-description" class="row">
         <!--  <a id="banner-desc" href="/index.php"
            style="border: 1px solid blue;
              min-height: 320px;
              margin-top: -50px;
              margin-left: -443px;
              margin-right: -473px;">
            <div hidden>
              Arquivo Senado
            </div>
            <div hidden>
              Senado Federal
            </div>
          </a> -->
      </div>
    </div>
  </div>
    <div id="sf-search-bar" class="span12">
      <div id="search-bar" style="top: 400px !important;">
        <?php echo get_component('search', 'box') ?>
      </div>
    </div>
</div>
