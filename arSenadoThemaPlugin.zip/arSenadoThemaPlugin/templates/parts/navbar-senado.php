<header>
<div id="header-institucional">
  <!--  navbar global-->
  <div class="sf-wrapper">
    <nav class="Triad navbar_global">
      <div>
       <button class="btn btn-lg btn-secondary js-sidebar-action sf-style-btn-menu" id="jstoggle" type="button" style="font-family: revert;">
          <i class="fas fa-bars"></i>
          <span class="u-hideLower title-n"> Menu</span>
        </button>
      </div>

      <div>
         <a class="navbar_global-brand sf-navbar-logo" href="https://www.senado.leg.br/" title="Senado Federal">
      <div id="sf-logo-senado" alt="Title"></div>
      </div>

      <div>
        <a id="sf-icon-hands-mobile" role="button" title="acessibilidade" class="js-vlibras u-hideUpper sf-icon-hands-mobile "></a>
        <a class="btn btn-lg btn-secondary u-hideUpper sf-style-phone-mobile"
          href="http://www12.senado.gov.br/institucional/falecomosenado">
          <i class="fas fa-phone"></i>
        </a>
          <div class="Rail Rail--fenced u-hideLower">
            <a class="js-vlibras" role="button" title="acessibilidade">
              <img src="/plugins/arSenadoThemaPlugin/images/senado/hands.svg" width="25px">
            </a>
            <a class="link link-deep"
            href="https://www12.senado.leg.br/institucional/responsabilidade-social/acessibilidade/pages/acessibilidade-no-portal-do-senado">Acessibilidade</a>
            <a class="link link-deep" href="http://www12.senado.gov.br/institucional/falecomosenado">Fale com o Senado</a>
          </div>
      </div>
    </nav>
  </div>

  <!-- sidebar -->
  <div class="sf-wrapper">
    <aside class="sidebar" style="visibility: hidden;">
      <div class="title mb-2 py-3 text-center border-bottom">MENU</div>
        <div class="sidebar-menu">
          <div class="sidebar-branch">
            <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Institucional
            </div>

            <!-- sub-menu 1 -->
            <div class="sidebar-wrapper">
              <div class="sidebar-menu">

                <div class="sidebar-title">
                  <a class="link link-light--tertiary" href="https://www12.senado.leg.br/institucional">
                  Institucional
                  </a>
                </div>

              <!-- Sobre o Senado -->
                <div class="sidebar-branch">
                  <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">
                    Sobre o Senado
                </div>
                  <div class="sidebar-wrapper">
                    <div class="sidebar-menu">
                      <div class="sidebar-title">Sobre o Senado</div>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/sobre-atividade">Atribuições</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/sobre-atividade">Composição</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/estrutura">Estrutura Administrativa</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/sobre-atividade">Funcionamento</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/documentos/sobre-o-senado/historia">História</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/responsabilidade-social">Responsabilidade Social</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www2.congressonacional.leg.br/visite">Visite o Senado</a>
                    </div>
                  </div>
                </div>

                <!-- Fale com o Senado -->
                <div class="sidebar-branch">
                  <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">
                    Fale com o Senado
                  </div>
                  <div class="sidebar-wrapper">
                    <div class="sidebar-menu">
                      <div class="sidebar-title">
                      <a class="link link-light--tertiary"
                        href="https://www12.senado.leg.br/institucional/falecomosenado">Fale com o Senado</a>
                      </div>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www.senado.leg.br/transparencia/LAI/secrh/parla_inter.pdf">Contato dos Senadores</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/falecomosenado">Contatosdo Senado</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www.senado.leg.br/transparencia/LAI/secrh/diretores_inter.pdf">Diretorese Coordenadores</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/transparencia/formtransparencia">Leide Acesso à Informação</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/ouvidoria">Ouvidoria</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/perguntas-frequentes">PerguntasFrequentes</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/redes-sociais">Redes Sociais</a>
                    </div>
                  </div>
                </div>

                <!-- Páginas Institucionais -->
                <div class="sidebar-branch">
                  <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Páginas Institucionais</div>
                  <div class="sidebar-wrapper">
                    <div class="sidebar-menu">
                      <div class="sidebar-title">Páginas Institucionais</div>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/responsabilidade-social/acessibilidade">Acessibilidade</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/eventos">Agendade Eventos</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/arquivo">Arquivo</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/biblioteca">Biblioteca</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/datasenado">DataSenado</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/delegacia-virtual">Delegacia Virtual</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/responsabilidade-social/equidade">Equidade</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/escoladegoverno">Escolade Governo</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://livraria.senado.leg.br/">Livraria</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/museu">Museu</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/omv">Observatório da Mulher</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/ouvidoria">Ouvidoria</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/presidencia">Presidência</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/procuradoria">Procuradoria da Mulher</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/sis">SIS/Saúde</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/responsabilidade-social/sustentabilidade">Sustentabilidade</a>
                    </div>
                  </div>
                </div>

                <!-- Serviços -->
                <div class="sidebar-branch">
                  <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Serviços</div>
                  <div class="sidebar-wrapper">
                    <div class="sidebar-menu">
                      <div class="sidebar-title">Serviços</div>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/carta-de-servicos">Carta de Serviços</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www.senado.leg.br/senado/hotsites/guialocalizacaosenado/index.html">Guia de Localização</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/pessoas/pessoas">Página Pessoas</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/jovemsenador">Programa Jovem Senador</a>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/estagio">Programa de Estágio</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="sidebar-branch">
                  <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Senadores</div>
                  <div class="sidebar-wrapper">
                     <div class="sidebar-menu">
                        <div class="sidebar-title">
                           <a class="link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores">Senadores</a>
                        </div>
                        <div class="sidebar-branch">
                           <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Legislatura Atual</div>
                           <div class="sidebar-wrapper">
                              <div class="sidebar-menu">
                                 <div class="sidebar-title">
                                  <a class="link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores">Legislatura Atual</a>
                                 </div>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores/em-exercicio">Senadores em Exercício</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores/comissao-diretora">Comissão Diretora</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores/liderancas-parlamentares">Lideranças Parlamentares</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores/fora-de-exercicio">Senadores Fora de Exercício</a>
                              </div>
                           </div>
                        </div>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores/legislaturas-anteriores">Legislaturas Anteriores</a>
                        <div class="sidebar-branch">
                           <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Presidentes</div>
                           <div class="sidebar-wrapper">
                              <div class="sidebar-menu">
                                 <div class="sidebar-title">
                                 <a class="link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores/presidentes">Presidentes</a>
                                 </div>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores/presidentes/imperio">Império (1826-1889)</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores/republica-velha">República Velha (1889 - 1930)</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores/pos-1930">Pós-1930</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores/pos-1964">Pós-1964</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores/nova-republica">Nova República</a>
                              </div>
                           </div>
                        </div>
                        <div class="sidebar-branch">
                           <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Mais</div>
                           <div class="sidebar-wrapper">
                              <div class="sidebar-menu">
                                <div class="sidebar-title">Mais</div>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/senadores/posse">Posse de Senadores</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/dados-abertos">Dados Abertos</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/perguntas-frequentes">Perguntas Frequentes</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar-branch">
                  <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Atividade Legislativa</div>
                  <div class="sidebar-wrapper">
                     <div class="sidebar-menu">
                        <div class="sidebar-title">
                        <a class="link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade">Atividade Legislativa</a>
                        </div>
                        <div class="sidebar-branch">
                           <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Plenário</div>
                           <div class="sidebar-wrapper">
                              <div class="sidebar-menu">
                                 <div class="sidebar-title">
                                 <a class="link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/sessao-plenaria">Plenário</a>
                                 </div>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/sessao-plenaria">Sessão Plenária</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www.senado.leg.br/atividade/plenario/ordemdodia">Ordem do Dia</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://legis.senado.leg.br/diarios/ver">Diários</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/pronunciamentos">Pronunciamentos</a>
                              </div>
                           </div>
                        </div>
                        <div class="sidebar-branch">
                           <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Comissões</div>
                           <div class="sidebar-wrapper">
                              <div class="sidebar-menu">
                                 <div class="sidebar-title">
                                 <a class="link link-light--tertiary" href="https://legis.senado.leg.br/comissoes">Comissões</a>
                                 </div>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://legis.senado.leg.br/comissoes">Agenda</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://legis.senado.leg.br/comissoes">Senado</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://legis.senado.leg.br/comissoes">Congresso</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://legis.senado.leg.br/comissoes/pesquisa_comissao">Pesquisar Comissões</a>
                              </div>
                           </div>
                        </div>
                        <div class="sidebar-branch">
                           <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Projetos e Matérias</div>
                           <div class="sidebar-wrapper">
                              <div class="sidebar-menu">
                                 <div class="sidebar-title">Projetos e Matérias</div>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/materias">Pesquisas</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/materias/acompanhamento/minhas-materias">Acompanhamento de Matérias</a>
                              </div>
                           </div>
                        </div>
                        <div class="sidebar-branch">
                           <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Informações
                              Legislativas
                           </div>
                           <div class="sidebar-wrapper">
                              <div class="sidebar-menu">
                                 <div class="sidebar-title">Informações Legislativas</div>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/relatorios-mensais">Relatórios Mensais</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/relatorio-da-presidencia">Relatórios da Presidência</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www9.senado.gov.br/QvAJAXZfc/opendoc.htm?document=senado%2Fpainel%20legislativo.qvw&amp;host=QVS%40www9&amp;anonymous=true">Estatísticas</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/autoridades">Autoridades</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/relatorios-legislativos/covid-19">Enfrentamento ao Coronavírus</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/falecomosenado/processo-legislativo">Atendimento ao Usuário</a>
                              </div>
                           </div>
                        </div>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/legislacao">Legislação</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/conselhos">Órgãos do parlamento</a>
                        <div class="sidebar-branch">
                           <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Mais</div>
                           <div class="sidebar-wrapper">
                              <div class="sidebar-menu">
                                 <div class="sidebar-title">Mais</div>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/autoridades">Autoridades</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/simplificou">Simplificou</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/perguntas-frequentes">Perguntas Frequentes</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/sobre-atividade">Entenda a Atividade Legislativa</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar-branch">
                  <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Comunicação</div>
                  <div class="sidebar-wrapper">
                     <div class="sidebar-menu">
                        <div class="sidebar-title">Comunicação</div>
                        <a class="sidebar-leaf link link-light--tertiary" href="http://www12.senado.leg.br/noticias">Senado Notícias</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="http://www12.senado.leg.br/radio">Rádio Senado</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="http://www12.senado.leg.br/tv">TV Senado</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="http://www12.senado.leg.br/multimidia">Senado Multimídia</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="http://www12.senado.leg.br/verifica">Senado Verifica</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="http://www12.senado.leg.br/fotos">Senado Fotos</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="http://www12.senado.leg.br/assessoria-de-imprensa">Assessoria de Imprensa</a>
                     </div>
                  </div>
               </div>
               <div class="sidebar-branch">
                <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Publicações</div>
                  <div class="sidebar-wrapper">
                     <div class="sidebar-menu">
                        <div class="sidebar-title">
                        <a class="link link-light--tertiary" href="https://www12.senado.leg.br/publicacoes">Publicações</a>
                        </div>
                        <div class="sidebar-branch">
                           <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Publicações Oficiais</div>
                           <div class="sidebar-wrapper">
                              <div class="sidebar-menu">
                                <div class="sidebar-title">
                                  <a class="link link-light--tertiary" href="https://www12.senado.leg.br/publicacoes">Publicações Oficiais</a>
                                </div>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://legis.senado.leg.br/diarios/ver">Diários</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="http://www.senado.leg.br/atividade/const/constituicao-federal.asp">Constituição Federal</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/regimento-interno">Regimento Interno</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/relatorio-da-presidencia">Relatório da Presidência</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/atividade/relatorios-mensais">Relatórios Mensais</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="http://www.senado.leg.br/publicacoes/anais/asp/PQ_Pesquisar.asp">Anais do Senado</a>
                              </div>
                           </div>
                        </div>
                            <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/publicacoes/estudos-legislativos/homeestudoslegislativos">Estudos Legislativos</a>
                            <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/orcamento/estudos-orcamentarios">Estudos Orçamentários</a>
                            <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/publicacoes/conselho-editorial-1">Conselho Editorial</a>
                            <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/ril">Revista de Informação Legislativa</a>
                        <div class="sidebar-branch">
                           <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Mais</div>
                           <div class="sidebar-wrapper">
                              <div class="sidebar-menu">
                              <div class="sidebar-title">Mais</div>
                               <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/perguntas-frequentes">Perguntas Frequentes</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar-branch">
                  <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Orçamento</div>
                  <div class="sidebar-wrapper">
                     <div class="sidebar-menu">
                        <div class="sidebar-title">
                        <a class="link link-light--tertiary" href="https://www12.senado.leg.br/orcamento">Orçamento</a>
                        </div>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/orcamento/legislacao-orcamentaria">Legislação Orçamentária</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/orcamento/estudos-orcamentarios">Estudos Orçamentários</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/orcamento/sigabrasil">SIGA Brasil</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/orcamentofacil">Orçamento Fácil</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/congresso/legislacao-e-publicacoes/glossario-orcamentario">Glossário</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/perguntas-frequentes">Perguntas Frequentes</a>
                     </div>
                  </div>
               </div>
               <div class="sidebar-branch">
                <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Transparência</div>
                  <div class="sidebar-wrapper">
                     <div class="sidebar-menu">
                        <div class="sidebar-title">
                        <a class="link link-light--tertiary" href="https://www12.senado.leg.br/transparencia">Transparência</a>
                        </div>
                          <a class="sidebar-leaf link link-light--tertiary" href="https://www25.senado.leg.br/web/transparencia/sen">Senadores</a>
                          <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/transparencia/prestacao-de-contas/transparencia-e-prestacao-de-contas">Prestação de Contas</a>
                          <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/transparencia/gestgov/HP-gestao-e-governanca">Gestão e Governança</a>
                          <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/transparencia/licitacoes-e-contratos/licitacoes-e-contratos">Licitações e Contratos</a>
                          <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/transparencia/rh/HP-recursos-humanos">Gestão de Pessoas</a>
                          <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/transparencia/orcamento-e-financas/orcamento-e-financas">Orçamento e Finanças</a>
                          <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/dados-abertos">Dados Abertos</a>
                        <div class="sidebar-branch">
                          <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Mais</div>
                           <div class="sidebar-wrapper">
                              <div class="sidebar-menu">
                                 <div class="sidebar-title">Mais</div>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/transparencia/sobre-1">Transparência Pública</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/transparencia/leg/legislacao-relacionada">Legislação Relacionada</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/transparencia/indice-de-transparencia-legislativa">Índice de Transparência</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/perguntas-frequentes">Perguntas Frequentes</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/transparencia/ctcs/conselho-de-transparencia">Conselho de Transparência</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="sidebar-branch">
                  <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">e-Cidadania</div>
                  <div class="sidebar-wrapper">
                     <div class="sidebar-menu">
                        <div class="sidebar-title">
                          <a class="link link-light--tertiary" href="https://www12.senado.leg.br/ecidadania">e-Cidadania</a>
                        </div>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/ecidadania/sobre">Sobre</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/ecidadania/principalideia">Ideia Legislativa</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/ecidadania/principalaudiencia">Evento Interativo</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/ecidadania/principalmateria">Consulta Pública</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/ecidadania/oficinalegislativa">Oficina Legislativa</a>
                        <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/ecidadania/login">Entrar</a>
                        <div class="sidebar-branch">
                           <div class="sidebar-toggle" aria-haspopup="true" aria-expanded="false" tabindex="0">Mais</div>
                           <div class="sidebar-wrapper">
                              <div class="sidebar-menu">
                                 <div class="sidebar-title">Mais</div>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/ecidadania/documentos/home/resultados">Relatórios</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/ecidadania/termo">Termos de Uso</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/ecidadania/validar-declaracao">Validação de Declaração</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www.senado.gov.br/bi-arqs/Arquimedes/ecidadania/relatorio-simplificado-ingles-pdf.pdf">English</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www.senado.gov.br/bi-arqs/Arquimedes/ecidadania/relatorio-simplificado-espanhol-pdf.pdf">Español</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/ecidadania/avalie">Fale Conosco</a>
                                 <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/perguntas-frequentes">Perguntas Frequentes</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="border-top my-2"></div>
                        <a class="sidebar-leaf link link-light--tertiary u-fontNormal" href="https://www12.senado.leg.br/institucional/presidencia">Presidência</a>
                        <a class="sidebar-leaf link link-light--tertiary u-fontNormal" href="https://www12.senado.leg.br/institucional/ouvidoria">Ouvidoria</a>
                        <a class="sidebar-leaf link link-light--tertiary u-fontNormal" href="https://www12.senado.leg.br/institucional/procuradoria">Procuradoria da Mulher</a>
                        <a class="sidebar-leaf link link-light--tertiary u-fontNormal" href="https://www12.senado.leg.br/institucional/omv">Observatório da Mulher</a>
                        <a class="sidebar-leaf link link-light--tertiary u-fontNormal" href="https://www12.senado.leg.br/interlegis">Interlegis</a>
                        <a class="sidebar-leaf link link-light--tertiary u-fontNormal" href="https://www12.senado.leg.br/ifi">Instituição Fiscal Independente</a>
                 <div class="border-top my-2"></div>
                       <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/falecomosenado">Fale com o Senado</a>
                       <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/transparencia/formtransparencia">Acesso à Informação</a>
                       <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/carta-de-servicos">Carta de Serviços</a>
                       <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/redes-sociais">Redes Sociais</a>
                       <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/documentos/politica-de-uso-do-portal-do-senado-federal">Política de uso</a>
                <div class="border-top my-2"></div>
                <div class="Rail Rail--fenced">
                       <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/carta-de-servicos/en/carta-de-servicos">English</a>
                       <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/carta-de-servicos/fr/carta-de-servicos">Français</a>
                       <a class="sidebar-leaf link link-light--tertiary" href="https://www12.senado.leg.br/institucional/carta-de-servicos/es/carta-de-servicos">Español</a>
               </div>
               <div class="border-top my-2"></div>
                      <a class="sidebar-leaf link link-light--tertiary" href="https://intranet.senado.leg.br/"><i class="fas fa-lock mr-1"></i>&nbsp;Intranet</a>
            </div>
         </aside>
      </div>
   </div>
</header>
</div>