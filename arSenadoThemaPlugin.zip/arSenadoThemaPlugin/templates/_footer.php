<footer>
<div id="footer-institucional">
    <div class="sf-wrapper">
        <footer class="Footer">
            <div class="container">
                <div class="Triad Triad--stackable">
                    <div class="Rail gamma my-2">
                        <a class="link link-deep--facebook" href="https://www.facebook.com/SenadoFederal" title="Facebook" target="_blank">
                            <i class="fab fa-facebook"></i>
                        </a>
                        <a class="link link-deep--twitter" href="https://twitter.com/senadofederal" title="Twitter" target="_blank">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a class="link link-deep--instagram" href="https://www.instagram.com/senadofederal" title="Instagram" target="_blank">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a class="link link-deep--youtube" href="https://www.youtube.com/user/TVSenadoOficial" title="Youtube" target="_blank">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                    <div class="Rail my-2">
                        <a href="https://www.camara.leg.br/" title="Câmara dos Deputados" target="_blank">
                            <div id="sf-icon-camara" alt="Câmara dos Deputados"></div>
                            <a href="https://www.congressonacional.leg.br/" title="Congresso Nacional" target="_blank">
                            <div id="sf-icon-congresso" alt="Congresso Nacional"></div>
                            <a href="https://www.tcu.gov.br/" title="Tribunal de Contas da União" target="_blank">
                            <div id="sf-icon-tcu" alt="Tribunal de Contas da União"></div>
                        </a>

                        </a>
                    </div>
                    <div class="Rail Rail--fenced my-2">
                        <a class="link link-deep" href="https://www12.senado.leg.br/institucional/carta-de-servicos/en/carta-de-servicos">ENGLISH</a>
                        <a class="link link-deep" href="https://www12.senado.leg.br/institucional/carta-de-servicos/es/carta-de-servicos">ESPAÑOL</a>
                        <a class="link link-deep" href="https://www12.senado.leg.br/institucional/carta-de-servicos/fr/carta-de-servicos">FRANÇAIS</a>
                    </div>
                </div>
                <div class="divider my-2"></div>
                <div class="Triad Triad--stackable">
                    <div class="my-2">
                        <a class="link link-deep" href="https://intranet.senado.leg.br/" title="Intranet">
                            <i class="fas fa-lock mr-1"></i> Intranet
                        </a>
                    </div>
                    <div class="Rail Rail--fenced Rail--stackable my-2">
                        <a class="link link-deep" href="https://www12.senado.leg.br/institucional/pessoas/pessoas">Servidor efetivo</a>
                        <a class="link link-deep" href="https://www12.senado.leg.br/institucional/pessoas/pessoas">Servidor comissionado</a>
                        <a class="link link-deep" href="https://www12.senado.leg.br/institucional/pessoas/pessoas">Servidor aposentado</a>
                        <a class="link link-deep" href="https://www12.senado.leg.br/institucional/pessoas/pessoas">Pensionista</a>
                    </div>
                    <div class="my-2">
                        <a class="link link-deep" href="https://www12.senado.leg.br/institucional/falecomosenado" title="fale com o Senado">
                            <i class="fas fa-phone u-flip-x mr-1"></i> Fale com o Senado
                        </a>
                    </div>
                </div>
                <div class="divider my-2"></div>
                <div class="d-flex justify-content-xl-center">
                    <span class="my-2">Senado Federal - Praça dos Três Poderes - Brasília DF - CEP 70165-900 | <span class="text-nowrap">Telefone: 0800 0 61 2211</span></span>
                </div>
             </div>
        </footer>
    </div>
</div>
</footer>
