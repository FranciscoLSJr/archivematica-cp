<?php decorate_with('layout_1col') ?>
<div id="sf-container-home">
  <div id="sf-welcome">
    <div>
      <h1><?php echo render_title($resource->getTitle(array('cultureFallback' => true))) ?></h1>
    </div>
    <div class="page">
      <?php echo render_value_html($sf_data->getRaw('content')) ?>
    </div>

    <div>
      <?php if (QubitAcl::check($resource, 'update')): ?>
          <section class="actions">
            <ul>
              <li><?php echo link_to(__('Edit'), array($resource, 'module' => 'staticpage', 'action' => 'edit'), array('title' => __('Edit this page'), 'class' => 'c-btn')) ?></li>
            </ul>
          </section>
      <?php endif; ?>
    </div>
    <section id="popular-this-week">
  
    <h2><?php echo __('Popular this week') ?></h2>
    <ul>
      <?php foreach ($popularThisWeek as $item): ?>
        <?php $object = QubitObject::getById($item[0]); ?>
        <li><a href="<?php echo url_for(array($object)) ?>"><?php echo render_title($object) ?><strong>&nbsp;&nbsp;<?php echo __('%1% visits', array('%1%' => $item[1])) ?></strong></a></li>
      <?php endforeach; ?>
    </ul>
  
    </section>
  </div>


  <div id="sf-information">
    <div>
      <h1>Informação</h1>
    </div>
    <div class="sf-information-items">
      <div>
        <img src="../plugins/arSenadoThemaPlugin/images/senado/icons/como-pesquisar.svg">
      </div>
      <div>
        <h4> <a href="/como-pesquisar-no-arquivo-senado ">Como pesquisar</a></h4>
        <span>Saiba como acessar nossos documentos dentro do <b>Arquivo Digital</b>.</span>
      </div>
    </div>

    <div class="sf-information-items">
      <div>
        <img src="../plugins/arSenadoThemaPlugin/images/senado/icons/histórico-do-senado.svg" style="width: 42px; height:42px;border-radius: 50px;">
      </div>
      <div>
        <h4><a href="hist-rico-do-senado">Histórico do Senado</a></h4>
        <span>Conheça os principais fatos que marcaram a história do  Senado e do Arquivo.</span>
      </div>
    </div>

    <div class="sf-information-items">
      <div>
        <img src="../plugins/arSenadoThemaPlugin/images/senado/icons/aspectos-técnicos.svg" style="width: 42px; height:42px;border-radius: 50px;">
      </div>
      <div>
        <h4><a href="/aspectos-t-cnicos ">Aspectos Técnicos</a></h4>
        <span>Acesse os estudos realizados para compreensão e organização do nosso acervo.</span>
      </div>
    </div>
  </div>

  <div id="sf-acervo">
    <div>
      <h1>Acervo</h1>
    </div>

    <div class="sf-acervo-items">
      <div>
        <img src="../plugins/arSenadoThemaPlugin/images/senado/icons/acervo-arquivistico.svg" style="width: 42px; height:42px;border-radius: 50px;">
      </div>
      <div>
        <h4><a href="/informationobject/browse">Acervo Arquivístico</a></h4>
      </div>
    </div>

    <div class="sf-acervo-items">
      <div>
        <img src="../plugins/arSenadoThemaPlugin/images/senado/icons/documentos-digitais.svg" style="width: 42px; height:42px;border-radius: 50px;">
      </div>
      <div>
        <h4><a href="/informationobject/browse?view=card&onlyMedia=1&topLod=0">Documentos Digitais</a></h4>
      </div>
    </div>

    <div class="sf-acervo-items">
      <div>
        <img src="../plugins/arSenadoThemaPlugin/images/senado/icons/pessoas-instituições.svg" style="width: 42px; height:42px;border-radius: 50px;">
      </div>
      <div>
        <h4><a href="/actor/browse">Pessoas e Instituições</a></h4>
      </div>
    </div>
    <div class="sf-acervo-items">
      <div>
        <img src="../plugins/arSenadoThemaPlugin/images/senado/icons/entidade-custodiadora.svg" style="width: 42px; height:42px;border-radius: 50px;">
      </div>
      <div>
        <h4><a href="/repository/browse">Entidade Custodiadora</a></h4>
      </div>
    </div>
    <div class="sf-acervo-items">
      <div>
        <img src="../plugins/arSenadoThemaPlugin/images/senado/icons/funções.svg" style="width: 42px; height:42px;border-radius: 50px;">
      </div>
      <div>
        <h4><a href=" /function/browse">Funções</a></h4>
      </div>
    </div>
    <div class="sf-acervo-items">
      <div>
        <img src="../plugins/arSenadoThemaPlugin/images/senado/icons/assuntos.svg" style="width: 42px; height:42px;border-radius: 50px;">
      </div>
      <div>
        <h4><a href="/taxonomy/index/id/35 ">Assuntos</a></h4>
      </div>
    </div>
    <div class="sf-acervo-items">
      <div>
        <img src="../plugins/arSenadoThemaPlugin/images/senado/icons/locais.svg" style="width: 42px; height:42px;border-radius: 50px;">
      </div>
      <div>
        <h4><a href="/taxonomy/index/id/42 ">Locais</a></h4>
      </div>
    </div>


  </div>
</div>


<!-- end_slot sidebar -->


